﻿namespace Classroom.MVC.Models;

public class CreateJoinScienceRequestDto
{
    public string UserName { get; set; }
}

