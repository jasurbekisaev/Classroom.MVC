﻿namespace Classroom.MVC.Models;
public class CreateScienceDto
{

    public string Name { get; set; }
    public string? Description { get; set; }
}
