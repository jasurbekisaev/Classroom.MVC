﻿namespace ClassRoomData
{
    public class Class1
    {

    }
}