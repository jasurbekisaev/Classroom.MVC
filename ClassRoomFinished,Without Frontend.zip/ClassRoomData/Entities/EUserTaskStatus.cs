﻿
namespace ClassRoomData.Entities;

public enum EUserTaskStatus
{
    Compeleted,
    Inprocess,
    Overdue,
    Rejected,
    Confirmed
}

