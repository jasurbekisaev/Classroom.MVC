﻿
namespace ClassRoomData.Entities;

public class Task
{
    public Guid Id { get; set; }
    public string Title { get; set; }
    public DateTime CreatedDate { get; set; } = DateTime.Now;
    public DateTime StartDate { get; set; }
    public DateTime FinishDate { get; set; }
    public string Description { get; set; }
    public Guid ScienceId { get; set; }
    public Science Science
    {
        get;
        set;
    }
}

