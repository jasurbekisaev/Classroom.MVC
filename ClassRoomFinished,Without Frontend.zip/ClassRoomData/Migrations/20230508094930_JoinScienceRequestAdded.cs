﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace ClassRoomData.Migrations
{
    /// <inheritdoc />
    public partial class JoinScienceRequestAdded : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_JoinScienceRequests_users_UserId",
                table: "JoinScienceRequests");

            migrationBuilder.DropColumn(
                name: "FromUser",
                table: "JoinScienceRequests");

            migrationBuilder.RenameColumn(
                name: "UserId",
                table: "JoinScienceRequests",
                newName: "FromUserId");

            migrationBuilder.RenameIndex(
                name: "IX_JoinScienceRequests_UserId",
                table: "JoinScienceRequests",
                newName: "IX_JoinScienceRequests_FromUserId");

            migrationBuilder.AddForeignKey(
                name: "FK_JoinScienceRequests_users_FromUserId",
                table: "JoinScienceRequests",
                column: "FromUserId",
                principalTable: "users",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_JoinScienceRequests_users_FromUserId",
                table: "JoinScienceRequests");

            migrationBuilder.RenameColumn(
                name: "FromUserId",
                table: "JoinScienceRequests",
                newName: "UserId");

            migrationBuilder.RenameIndex(
                name: "IX_JoinScienceRequests_FromUserId",
                table: "JoinScienceRequests",
                newName: "IX_JoinScienceRequests_UserId");

            migrationBuilder.AddColumn<Guid>(
                name: "FromUser",
                table: "JoinScienceRequests",
                type: "uniqueidentifier",
                nullable: false,
                defaultValue: new Guid("00000000-0000-0000-0000-000000000000"));

            migrationBuilder.AddForeignKey(
                name: "FK_JoinScienceRequests_users_UserId",
                table: "JoinScienceRequests",
                column: "UserId",
                principalTable: "users",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
