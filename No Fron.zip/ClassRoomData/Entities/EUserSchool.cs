﻿
namespace ClassRoomData.Entities;

public enum EUserSchool
{
    Founder,
    Admin,
    Teacher,
    student
}

public enum EUserScience
{
    Teacher,
    Student
}