﻿namespace Classroom.MVC.Models;

public class CreateCommentDto
{
    public string Comment { get; set; }
}
