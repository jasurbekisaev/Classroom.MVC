﻿
namespace ClassRoomData.Entities;

public enum ETaskStatus
{
    Created,
    Active,
    Expired,
}
